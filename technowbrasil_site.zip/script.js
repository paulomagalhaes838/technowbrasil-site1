
const perfilBtn = document.getElementById('perfilBtn');
const perfilDropdown = document.getElementById('perfilDropdown');
const authSection = document.getElementById('authSection');

perfilBtn.addEventListener('click', () => {
  perfilDropdown.style.display =
    perfilDropdown.style.display === 'block' ? 'none' : 'block';
});

function toggleAuth() {
  authSection.style.display =
    authSection.style.display === 'block' ? 'none' : 'block';
  perfilDropdown.style.display = 'none';
}
